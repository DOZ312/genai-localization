## GenAi Localization
*This is a localization project for GenAi Discord bot (https://genai.altir.xyz/)*

**Before creating pull request, run validate script `node validate <your pr's language>`. Otherwise, your pull request will be rejected!**